The game is mostly done. It is slightly imbalanced right now, meaning that it might be difficult to win.
However, by my count, it should have 58 points of features right now.

There are a handful of bugs that I am aware of right now that I do not know how to fix:
- The printsituation() function sometimes prints monsters that are not alive. If you leave the room, they
	should disappear.
- Sometimes, a monster can hit you for lethal damage immediately upon fighting you. This is not intentional,
	but I have not figured out how to fix it yet.

Apart from that, please take the contents of the starter chest or you risk soft-locking yourself.